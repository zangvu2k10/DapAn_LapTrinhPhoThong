n, k = map(int,input(). split())
print(int(n / k))
print(n % k)
print(round(n / k, 2))