n, x = map(int, input(). split())
a = input().split() 
dem = 0
for v in a : 
    if int(v) >= x : dem += 1
print(dem)