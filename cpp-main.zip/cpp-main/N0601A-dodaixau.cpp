//http://laptrinhphothong.vn/Problem/Details/4621
#include <iostream>
#include<string.h>
using namespace std;
char s[101];
int len;
int main() {
    gets(s);
    len = strlen(s);
    cout <<len;
    return 0;
}
    