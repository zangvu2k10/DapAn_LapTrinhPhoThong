#include <iostream>
using namespace std;
class HS{
public : 
    HS(){ //  đây là 1 phương thức khởi tạo 
        cout<<"Constructor Called";
    }
};
int main(){
    HS hs;
}