#include <iostream>
#define ulli long long int
using namespace std;
ulli n;

int main() {
	cin >> n;
	ulli kq = ((n/2) * (n/2));
	cout << kq;
}
    